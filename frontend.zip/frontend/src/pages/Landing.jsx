import { useState } from 'react';
import { Link } from 'react-router-dom';
import { Sparkles, Code2, Mic, FileCheck2, ArrowRight, CheckCircle2, Flame } from 'lucide-react';
import { ThemeToggle } from '../components/Topbar';

const PREVIEW_TABS = {
  ats: {
    title: 'Instant ATS Resume Scorer',
    badge: '92/100 Match Score',
    description: 'Upload your PDF resume and get keyword gap analysis tailored for SDE, Data Analyst, and Product roles.',
    metrics: ['Strong React & Node.js project impact', 'Add quantifiable latency/throughput metrics', 'ATS formatting check passed'],
  },
  compiler: {
    title: 'Multi-Language Live Code Compiler',
    badge: 'Python • C++ • Java • JS',
    description: 'Write, compile, and benchmark DSA solutions right inside your browser with AI Big-O complexity feedback.',
    metrics: ['O(n) Time Complexity verified', 'Custom stdin test case runner', 'Instant AI edge-case hints'],
  },
  interview: {
    title: 'AI Mock Interviewer',
    badge: 'Real-Time Scoring',
    description: 'Practice realistic technical & behavioral rounds with adaptive follow-up questions and 10-point answer grading.',
    metrics: ['Role-specific SDE & Core CS questions', 'Instant feedback on clarity & depth', 'Earn +50 XP per completed round'],
  },
};

export default function Landing() {
  const [activeTab, setActiveTab] = useState('ats');
  const current = PREVIEW_TABS[activeTab];

  return (
    <div className="min-h-screen transition-colors duration-300">
      {/* Top Navigation */}
      <nav className="max-w-7xl mx-auto px-6 py-5 flex items-center justify-between">
        <div className="flex items-center gap-2.5">
          <div className="w-9 h-9 rounded-xl bg-orange-500 flex items-center justify-center text-white font-bold shadow-md">
            S
          </div>
          <span className="text-xl font-extrabold tracking-tight">SafalPath AI</span>
        </div>
        <div className="flex items-center gap-3">
          <ThemeToggle />
          <Link to="/login" className="px-4 py-2 text-sm font-semibold hover:text-orange-500 transition">
            Log in
          </Link>
          <Link
            to="/register"
            className="px-5 py-2.5 rounded-xl bg-orange-500 hover:bg-orange-600 text-white text-sm font-semibold shadow-md transition hover:scale-105"
          >
            Get Started Free
          </Link>
        </div>
      </nav>

      {/* Hero Section with Animated Floating Cards & Visuals */}
      <section className="max-w-7xl mx-auto px-6 py-14 grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
        <div className="space-y-6">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-orange-500/10 text-orange-500 text-xs font-bold">
            <Flame className="w-4 h-4" />
            <span>Your Gamified AI Placement Copilot</span>
          </div>
          <h1 className="text-4xl sm:text-5xl font-extrabold leading-tight tracking-tight">
            Crack Your Dream Tech Placement with <span className="text-orange-500">AI Precision.</span>
          </h1>
          <p className="text-base sm:text-lg opacity-75 leading-relaxed">
            Score your resume against real ATS filters, practice live DSA coding in C++/Python/Java/JS, and take AI mock interviews with instant feedback.
          </p>
          <div className="flex flex-wrap items-center gap-4 pt-2">
            <Link
              to="/register"
              className="inline-flex items-center gap-2 px-6 py-3.5 rounded-2xl bg-orange-500 hover:bg-orange-600 text-white font-bold shadow-lg transition hover:translate-y-[-2px]"
            >
              Start Preparing Free <ArrowRight className="w-4 h-4" />
            </Link>
            <Link
              to="/login"
              className="px-6 py-3.5 rounded-2xl border theme-card font-semibold hover:border-orange-500 transition"
            >
              Explore Dashboard
            </Link>
          </div>
        </div>

        {/* Visual Showcase + Floating Animated Badges */}
        <div className="relative">
          <div className="rounded-3xl overflow-hidden border theme-card shadow-2xl">
            <img
              src="https://images.unsplash.com/photo-1522202176988-66273c2fd55f?auto=format&fit=crop&w=1000&q=80"
              alt="Students collaborating on software engineering interviews"
              className="w-full h-[380px] object-cover"
            />
          </div>

          <div className="animate-float absolute -bottom-6 -left-4 sm:-left-6 p-4 rounded-2xl border theme-card shadow-xl flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-emerald-500/15 text-emerald-500 flex items-center justify-center font-bold">
              92%
            </div>
            <div>
              <p className="text-xs font-bold">ATS Resume Match</p>
              <p className="text-[11px] opacity-70">+38% callback boost</p>
            </div>
          </div>

          <div className="animate-float absolute -top-5 -right-3 sm:-right-5 p-4 rounded-2xl border theme-card shadow-xl flex items-center gap-2.5">
            <Sparkles className="w-5 h-5 text-orange-500" />
            <div>
              <p className="text-xs font-bold">Margdarshak AI</p>
              <p className="text-[11px] opacity-70">24/7 Placement Mentor</p>
            </div>
          </div>
        </div>
      </section>

      {/* Interactive Feature Switcher */}
      <section className="max-w-5xl mx-auto px-6 py-16 space-y-8">
        <div className="text-center space-y-2">
          <h2 className="text-2xl sm:text-3xl font-extrabold">Interactive Placement Toolkit</h2>
          <p className="text-sm opacity-70">Click each module below to preview how SafalPath trains you end-to-end</p>
        </div>

        <div className="flex flex-wrap justify-center gap-3">
          {[
            { id: 'ats', label: 'ATS Resume Scorer', icon: FileCheck2 },
            { id: 'compiler', label: 'Live Code Compiler', icon: Code2 },
            { id: 'interview', label: 'AI Mock Interviewer', icon: Mic },
          ].map((tab) => {
            const Icon = tab.icon;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`flex items-center gap-2 px-5 py-3 rounded-2xl font-semibold text-sm transition cursor-pointer ${
                  activeTab === tab.id
                    ? 'bg-orange-500 text-white shadow-md scale-105'
                    : 'border theme-card hover:border-orange-500'
                }`}
              >
                <Icon className="w-4 h-4" />
                {tab.label}
              </button>
            );
          })}
        </div>

        <div className="p-8 rounded-3xl border theme-card shadow-lg transition-all duration-300 space-y-4">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <h3 className="text-xl font-bold">{current.title}</h3>
            <span className="px-3 py-1 rounded-full bg-orange-500/15 text-orange-500 text-xs font-bold">
              {current.badge}
            </span>
          </div>
          <p className="text-sm opacity-80 leading-relaxed">{current.description}</p>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-2">
            {current.metrics.map((item, idx) => (
              <div key={idx} className="p-3.5 rounded-xl border theme-card flex items-start gap-2.5 text-xs font-medium">
                <CheckCircle2 className="w-4 h-4 text-emerald-500 shrink-0 mt-0.5" />
                <span>{item}</span>
              </div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}